<?php 
include 'header.php';
?>
<div class="container">

		<div class="row justify-content-center">
			<div class="col-lg-5">
				<h3 class="text-center">LOGIN FORM </h3>
				<form action="logindb.php" method="POST" class="form bg-light">
				<div class="mb-3">
					<label class="form-label">Email or User name</label>
					<input type="text" name="name" class="form-control" placeholder="name@example.com" required>
				</div>

				<label for="inputPassword5" class="form-label">Password</label>
					<input type="text"  name="password" class="form-control" required>
					<input type="submit" name="submit" class="btn btn-primary mt-2">
				</form>	
				<a href="register.php"class="btn btn-primary mt-2">Register Form</a>
			</div>
		
		</div>

</div>