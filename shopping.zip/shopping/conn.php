 <?php
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname="shoppingdb";

			// Create connection
			$conn = new mysqli($servername, $username, $password,$dbname);

			// Check connection
			if ($conn->connect_error) {
			  die("Connection failed: " . $conn->connect_error);
			}
			$db="CREATE DATABASE IF NOT EXISTS shoppingdb";
				mysqli_query($conn, $db);
			// sql to create admin table
				$sql = "CREATE TABLE  IF NOT EXISTS admin (
				
				 
				email VARCHAR(50) NOT NULL PRIMARY KEY,
				username VARCHAR(50) NOT NULL,
				password VARCHAR(50) NOT NULL
				)";
				mysqli_query($conn, $sql);
				
				 // sql to create table for product
				$sql = "CREATE TABLE  IF NOT EXISTS product (
				id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
				productname VARCHAR(30) NOT NULL,
				productdesc VARCHAR(50) NOT NULL,
				price VARCHAR(50),
				images VARCHAR(50)
				)";
				mysqli_query($conn, $sql);
				
				// sql to create table for user database
				$sql = "CREATE TABLE  IF NOT EXISTS user_form (
				
				 
				email VARCHAR(50) NOT NULL PRIMARY KEY,
				username VARCHAR(50) NOT NULL,
				password VARCHAR(50) NOT NULL
				)";
				mysqli_query($conn, $sql);
			?>