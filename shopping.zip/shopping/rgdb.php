<?php


		include 'conn.php';
		$name=$_POST['name'];
		$email=$_POST['email'];
		$password=$_POST['password'];
		
			// sql to create table
				$sql = "CREATE TABLE  IF NOT EXISTS user_form (
				
				 
				email VARCHAR(50) NOT NULL PRIMARY KEY,
				username VARCHAR(50) NOT NULL,
				password VARCHAR(50) NOT NULL
				)";
				mysqli_query($conn, $sql);
				
				
				
					if(isset($_POST['submit']))
					{
				$s="SELECT * FROM user_form WHERE username='$name'";	
				$result=mysqli_query($conn,$s );
					if ($result->num_rows > 0) 
						{
						
							echo "<script> alert('Email already added');
								window.location.href='register.php'; </script>";
							
						}
						else
						{
									//insert user reg. data in table user_form
								$sql2="INSERT INTO user_form (username, email,password) VALUES ('$name','$email','$password')";
							
						  if (mysqli_query($conn, $sql2))
								{ 
							
								echo "<script> alert('your account has been created');
								window.location.href='login.php';</script>";					 
								}
						}
						
					}
					
  
?>