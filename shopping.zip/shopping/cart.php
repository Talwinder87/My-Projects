

<?php


include 'header.php';

include 'conn.php';
		
						
?>
<div class="container">
	<div class="row justify-content-center">
		<h3 class="text-center">Shopping Cart</h3>
		<div class="col-lg-6">
			<table class="table">
					  <thead>
						<tr>
							<th scope="col">Serial no.</th>
							<th scope="col">Product image</th>
						  <th scope="col">Product name</th>
						   <th scope="col">Price</th>
						   <th scope="col"></th>
						  
						</tr>
						</thead>
						
					 
					  <tbody>
					  <?php  
								if(isset($_SESSION['cart']))
								{
									$serial=0;
									$total=0;
								foreach($_SESSION['cart'] as $i=>$v)
								{
									$serial++;
									$total +=$v['price']; ?>
						<tr>
						<td class="align-middle"><?php echo $serial; ?></td>
						  <td><img src="images/<?php echo $v['images'];?>" class="img_fluid"></td>
						  <td class="align-middle"><?php echo $v['p_name']; ?></td>
						  <td class="align-middle"><?php echo $v['price']; ?></td>
						  <td class="align-middle"><form action="manage_cart.php" method="GET"><a href="manage_cart.php?delete=<?php echo $v['p_name']; ?>" class="delete-btn btn btn-primary" > <i class="fas fa-trash"></i> delete </a></form>
						  </td>
						   
						</tr>
								<?php } 
									if(count($_SESSION['cart'])==0)
									{
										echo "<td class='align-middle'>No items in cart</td>";
									}
								}
								else {
								echo "No items add to cart by you"; }
								?>
								<tr>
								<td class="align-middle"> <a href="order.php" class="btn btn-primary"  >Palace Order</a></td>
								</tr>
						</tbody>
						</table>
			</div>
				<div class="col-lg-4">
				
					<?php if(isset($_SESSION['cart']))
					{
						if(count($_SESSION['cart'])>0)
						{
							echo "<tr><h3 style='display:inline'>Total : </h3>$total  </tr>	";
								
							
						}
					}?>
				
				</div>
		</div>
	</div>