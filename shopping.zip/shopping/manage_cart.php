<?php
session_start();
?>




<?php


include 'conn.php';


		
		
		if(isset($_SESSION['user']))
		{
			if(isset($_GET['add']))
			{		
				$product_id=$_GET['add'];
				$sql="select * from product where id='$product_id'";
				$result=mysqli_query($conn,$sql);
			 while($row = $result->fetch_assoc()) {
				 
				 
					$p_name=$row['productname'];	
					$price=$row['price'];
					$img=$row['images'];
						
						
				 }
			}	
				
				
				if(isset($_SESSION['cart']))
					{
						if(isset($_GET['add']))
						{
							$colm_val=array_column($_SESSION['cart'],'p_name');
							if(in_array($p_name, $colm_val))
							{
								echo "<script> alert('product already added');
							window.location.href='index.php';</script>";
							}
							else
							{
							$count=count($_SESSION['cart']);
							$_SESSION['cart'][$count]=array("id"=>$product_id,"images"=>$img, "p_name"=>$p_name,"price"=>$price);
							echo "<script> alert('product added');
							window.location.href='index.php';</script>";
							}
						}
					}
				else
					{
			
						$_SESSION['cart'][0]=array("id"=>$product_id,"images"=>$img, "p_name"=>$p_name,"price"=>$price);
						print_r($_SESSION['cart']);
						echo "<script> alert('product added');
						window.location.href='index.php';</script>";
			
				}
		}
		else
		{
			header('location:login.php');
			
		}
		
		
		
		
		//delete product from shopping cart
		
		if(isset($_GET['delete']))
		{
			foreach($_SESSION['cart'] as $key=>$val)
				if($val['p_name']==$_GET['delete'])
				{
					
					unset($_SESSION['cart'][$key]);
					$_SESSION['cart']=array_values($_SESSION['cart']);
					
					echo "<script> alert('product delete');
					window.location.href='cart.php';
			</script>";
				}
			
		}
		?>