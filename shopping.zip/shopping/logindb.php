<?php

session_start();

include 'conn.php';
		$name=$_POST['name'];
		$password=$_POST['password'];
		
		if(isset($_POST['submit']))
					{
				$s="SELECT email, username, password FROM user_form WHERE username='$name'  and password='$password'";	
				$result=mysqli_query($conn,$s );
					if ($result->num_rows > 0) 
						{
							
							 $_SESSION['user']=$name;
						 header('location:index.php');
						
							
							
						}
					else
					{
						echo "<script> alert('wrong user name or password');
								window.location.href='login.php';</script>";
						
					}
					}


?>