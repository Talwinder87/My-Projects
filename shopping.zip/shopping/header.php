<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Online Shopping</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" integrity="sha384-4LISF5TTJX/fLmGSxO53rV4miRxdg84mZsxmO8Rx5jGtp/LbrixFETvWa5a6sESd" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  </head>
  <body>
   <!--Nav bar-->
   
		   <nav class="navbar navbar-expand-lg bg-body-tertiary">
		  <div class="container-fluid">
			<a class="navbar-brand" href="#">TSB Shopping</a>
		

			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			  <span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNav">
			  <ul class="navbar-nav">
				<li class="nav-item">
				  <a class="nav-link active link-primary" aria-current="page" href="index.php">Home</a>
				</li>
				<li class="nav-item">
				  <a class="nav-link link-primary" href="index.php">Products</a>
				</li>
				<li class="nav-item">
				  <a class="nav-link link-primary" href="#">Contact Us</a>
				</li>
				<li class="nav-item">
				<?php if(isset($_SESSION['user']))
				{
				 echo ' <a class="nav-link link-danger" href="logout.php">Logout</a>'; 
				}
				else
				{
					echo ' <a class="nav-link link-primary" href="login.php">Login</a>';
				}
				
				?>
				</li>
				<li class="nav-item">
				 <?php if(isset($_SESSION['user']))
					  
					  {
						  echo "Welcome: ".$_SESSION['user'];
						  
						  
					  }
				  
				  ?>
				</li>
				<li class="nav-item">
				  <a class="nav-link link-dark" href="adminlogin.php">Admin </a>
				</li>
				<?php if(isset($_SESSION['admin'])){
				echo '<li class="nav-item">
				  <a class="nav-link" href="admin.php">Admin Dashboard </a>
				</li> ';  }?>
				<?php if(isset($_SESSION['admin'])){
				echo '<li class="nav-item">
				  <a class="nav-link" href="adminlogout.php">Admin Logout </a>
				</li> ';  }?>
				
			  </ul>
			  <?php if(isset($_SESSION['cart']) OR isset($_SESSION['admin']))
			  { 
				
				}?>
				<a class="btn btn-primary" href="cart.php" role="button"><i class="bi bi-cart4"></i>Cart(<?php if(isset($_SESSION['cart'])){
					$count=count($_SESSION['cart']);
					echo $count; }?> )</a>

			</div>
		  </div>
		</nav>
	<!--End navbar-->