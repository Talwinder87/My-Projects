
<?php

include 'header.php';
include 'conn.php';

?>	

<!-- fetch data from database-->
<?php
			$sql="select * from product";
			$result=mysqli_query($conn,$sql);

?>


		<!--show Products -->
				<div class="container mt-4">
				<div class="row">
					
				<?php while($row = $result->fetch_assoc()) 
					{ ?> 
						

					<div class="col-lg-4">
						<div class="card" style="width: 18rem;">
							<!--FORM-->
							<form action="manage_cart.php" method="GET">
							  <img class="card-img-top" src="images/<?php echo $row['images']?>" alt="Card image cap" name="images">
							  <div class="card-body">
								<h5 class="card-title" name="p_name"><?php echo $row['productname']?></h5>
								<p class="card-text"><?php echo $row['productdesc']?></p>
								<p class="card-text" name="price">Price: <?php echo $row['price']?></p>
							  </div>
							   
							  <div class="card-body">
							  
								
								<a href="manage_cart.php?add=<?php echo $row['id']; ?>"  class=" btn btn-primary ">Add to cart</a>	
								</form>
							</div>
					</div>
				  </div>
					<?php }?>
				   
					
				 
			</div>
			</div>
			
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>