<?php
include 'header.php';
if(isset($_SESSION['admin']))
{
	
	if(isset($_POST['update_product'])){
   $update_p_id = $_POST['update_p_id'];
   $update_p_name = $_POST['update_p_name'];
   $update_p_price = $_POST['update_p_price'];
   

   $update_query = mysqli_query($conn, "UPDATE `products` SET name = '$update_p_name', price = '$update_p_price', image = '$update_p_image' WHERE id = '$update_p_id'");

   if($update_query){
      move_uploaded_file($update_p_image_tmp_name, $update_p_image_folder);
      $message[] = 'product updated succesfully';
      header('location:admin.php');
   }else{
      $message[] = 'product could not be updated';
      header('location:admin.php');
   }

}
	
	
	
echo	'<div class="container">
<DIV class="row justify-content-center">
<div class="col-lg-10">
<h3 class="text-center"> ADMIN PANEL </h3>
</div>
	<div class="col-lg-4">
		 <div class="card-body border p-2 mt-3">
				 <h5 class="card-title text-center">Add Products</h5>
				 
				  <form action="product.php" method="POST" class="py-3">
					
					<div class="mb-3">
				  <label for="formFileSm" class="form-label">Select Product Image</label>
				  <input class="form-control form-control-sm" type="file" name="image">
					</div>
					<div class="col-auto">
					<label  class="col-form-label">Product Name</label>
				  </div>
					<div class="col-auto">
					<input type="text"  class="form-control" name="product_name">
				  </div>
				  
				  <div class="col-auto">
					<label  class="col-form-label">Product Description</label>
				  </div>
				  <div class="col-auto">
					<input type="text"  class="form-control" name="product_desc">
				  </div>
				  
				  <div class="col-auto">
					<label  class="col-form-label">Price</label>
				  </div>
				  <div class="col-auto">
					<input type="text"  class="form-control" name="price">
				  </div>
				  
				 <input class="btn btn-primary mt-2" type="submit" value="Add Product" name="submit">


				</form>
				
		</div>
	</div>	
</div>		
</div>';?>
	<?php
			include 'conn.php';?>
			
			
			<?php
			
			$sql="select * from product";
			$result=mysqli_query($conn,$sql);
			
			
				?>
				<div class="container">
						
						
						
					<table class="table">
					  <thead>
						<tr>
							<th scope="col">product image</th>
						  <th scope="col">product name</th>
						  <th scope="col">product Description</th>
						  <th scope="col">price</th>
						  
						</tr>
						</thead>
						<?php while($row = $result->fetch_assoc()) 
					{ ?>
					 
					  <tbody>
						<tr>
						  <td><img src="images/<?php echo $row['images'];?>" class="img_fluid"></td>
						  <td><?php echo $row['productname']; ?></td>
						  <td> <?php echo $row['productdesc']; ?></td>
						  <td><?php echo $row['price']; ?></td>
						  <td> <form action="product.php" method="GET"><a href="product.php?delete=<?php echo $row['id']; ?>" class="delete-btn btn btn-primary" onclick="return confirm('are your sure you want to delete this?');"> <i class="fas fa-trash"></i> delete </a></form>
						  </td>
						  <!-- Upadete button-->
							<td> <form action="product.php" method="GET"><a href="product.php?update=<?php echo $row['id']; ?>" class=" btn btn-primary" > <i class="fas fa-trash"></i> Update </a></form>
						  </td>
						</tr>
					<?php }?>
						</tbody>
						</table>
						
						
						
				
				
      <?php
	  if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_query = mysqli_query($conn, "DELETE FROM `product` WHERE id = $delete_id ") or die('query failed');
   if($delete_query){
      header('location:admin.php');
      
   }else{
      header('location:admin.php');
     
   }
}
	
	  
 } 
 else
 {
	 header('location:index.php');
	 
 }
	?>
					 
					<script>
					function alert() {
						var x;
						var r = confirm("Press OK or Cancel button");
						if (r == true) {
						  var id=document.getElementById("id").value;
						  document.getElementById("demo").innerHTML = id; 
					 }
						else {
						 x = "You pressed Cancel!";
					 }
					 
				}
					</script>; 
				

