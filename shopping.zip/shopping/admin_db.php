<?php

session_start();

include 'conn.php';
		$name=$_POST['name'];
		$password=$_POST['password'];
		
		if(isset($_POST['submit']))
					{
				$s="SELECT email, username, password FROM admin WHERE username='$name'  and password='$password'";	
				$result=mysqli_query($conn,$s );
					if ($result->num_rows > 0) 
						{
						 header('location:admin.php');
						 $_SESSION['admin']=$name;
							
							
						}
					else
					{
						echo "<script> alert('wrong user name or password');
								window.location.href='adminlogin.php';</script>";
						
					}
					}


?>