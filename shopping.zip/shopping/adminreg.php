<?php


		include 'conn.php';
		$name=$_POST['name'];
		$email=$_POST['email'];
		$password=$_POST['password'];
		
				
				
				
				
					if(isset($_POST['submit']))
					{
				$s="SELECT * FROM admin WHERE username='$name'";	
				$result=mysqli_query($conn,$s );
					if ($result->num_rows > 0) 
						{
						
							echo "<script> alert('Username already added');
								window.location.href='adminreg.php'; </script>";
							
						}
						else
						{
									//insert user reg. data in table user_form
								$sql2="INSERT INTO admin (username, email,password) VALUES ('$name','$email','$password')";
							
						  if (mysqli_query($conn, $sql2))
								{ 
							
								echo "<script> alert('your account has been created');
								window.location.href='adminlogin.php';</script>";					 
								}
						}
						
					}
					
  
?>