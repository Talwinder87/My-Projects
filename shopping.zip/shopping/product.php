<?php
session_start();

?>


	<?php
	
			
						$image=$_POST['image'];
	
				$pro_name=$_POST['product_name'];
				$pro_desc=$_POST['product_desc'];
				$price=$_POST['price'];
				
				echo $price;
	
	?>
	
				
				<?php include 'conn.php';
			
			
			if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_query = mysqli_query($conn, "DELETE FROM `product` WHERE id = $delete_id ") or die('query failed');
   if($delete_query){
      header('location:admin.php');
      
   }else{
      header('location:admin.php');
      $message[] = 'product could not be deleted';
   }
}
			
			
			 // sql to create table
				$sql = "CREATE TABLE  IF NOT EXISTS product (
				id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
				productname VARCHAR(30) NOT NULL,
				productdesc VARCHAR(50) NOT NULL,
				price VARCHAR(50),
				images VARCHAR(50)
				)";
				mysqli_query($conn, $sql);
					
				$s="select * from product";	
				$result=mysqli_query($conn,$s );
			
							if(isset($_POST['submit']))
							{
							$sql2="INSERT INTO product (productname, productdesc, price, images) VALUES ('$pro_name','$pro_desc','$price','$image')";
							
						  if (mysqli_query($conn, $sql2))
						{ 
							
							$_SESSION['start']= "red";
							header("location:admin.php");					 
						}
						else{  

							echo "Could not insert record: ". mysqli_error($conn);  

						} 
							}
				

				
				
				
				/* 
				 echo "<script> alert('record successfully inserted') </script>";
				// OUTPUT DATA OF EACH ROW 
					while($row = $result->fetch_assoc()) 
					{ 
				
					<table class="table">
					  <thead>
						<tr>
						  <th scope="col">#</th>
						  <th scope="col">First</th>
						  <th scope="col">Last</th>
						  <th scope="col">Handle</th>
						</tr>
					  </thead>
					  <tbody>
						<tr>
						  <th scope="row">1</th>
						  <td>Mark</td>
						  <td>Otto</td>
						  <td>@mdo</td>
						</tr>
						</tbody>
						</table>
				echo  "".$row["productname"]. "<br>"
						.$row["productdesc"].""; 
				
				  */ 
			
				//$sql="insert into product (productname,productdesc,price) values ()";
			
			
			
			
			/* 
		/* /* 	/* $sql="DROP TABLE IF  EXISTS product"; 
			if($conn->query($sql)==true)
			{
				echo " table drop";
			}
			else
			{echo "not drop";} 
			
			
			
			 $sql="SELECT COUNT(*)FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'shoppingdb' AND TABLE_NAME = 'product1'";
 
		 $result = $conn->query($sql);
		 
		 if($result->num_rows > 0) 
		 {
			 echo "table exist";
		 }
		 else{
			 echo "no table";
		 } 
 
				 SQL query
			$sql = "SHOW TABLES IN `shoppingdb`";

			// perform the query and store the result
			$result = $conn->query($sql);

			// if the $result not False, and contains at least one row
			if($result !== false) {
			  // if at least one table in result
			  if($result->num_rows > 0) {
				// traverse the $result and output the name of the table(s)
				while($row = $result->fetch_assoc()) {
				  echo '<br />'. $row['Tables_in_shoppingdb'];
				}
			  }
			  else echo 'There is no table in "tests"';
			}
			else echo 'Unable to check the "tests", error - '. $conn->error; 

			 // sql to create table
				$sql = "CREATE TABLE  IF NOT EXISTS product (
				id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
				productname VARCHAR(30) NOT NULL,
				productdesc VARCHAR(50) NOT NULL,
				price VARCHAR(50)
				)";

				if ($conn->query($sql) === TRUE) {
				  echo "Table producttable created successfully";
				} else {
				  echo "Error creating table: " . $conn->error;
				}

				$conn->close() ;*/ 
				?>  