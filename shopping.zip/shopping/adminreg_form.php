	<?php 
include 'header.php';
?>
	<div class="container">

		<div class="row justify-content-center">
			<div class="col-lg-5">
				<h3 class="text-center">ADMIN REGISTER FORM </h3>
				<form action="adminreg.php" method="POST" class="form bg-light">
				
				<div class="mb-3">
					<label for="exampleFormControlInput1" class="form-label"> Name</label>
					<input type="text" class="form-control" name="name" id="exampleFormControlInput1" placeholder="">
				</div>
				<div class="mb-3">
					<label for="exampleFormControlInput1" class="form-label"> Email address</label>
					<input type="email" class="form-control" name="email" id="exampleFormControlInput1" placeholder="name@example.com">
				</div>

					<label class="form-label">Password</label>
					<input type="text"  name="password" class="form-control">
					
					<input type="submit" class="btn btn-primary mt-2" name="submit" >
				</form>	
				
			</div>
		
		</div>

</div>